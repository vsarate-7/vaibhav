package edu.rit.shiv.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText w1,h1,e1;
    Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        w1 = findViewById(R.id.w1);
        h1 = findViewById(R.id.h1);
        e1 = findViewById(R.id.e1);
        b1 = findViewById(R.id.b1);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float n1 =  Float.parseFloat(w1.getText().toString());
                float n2 = Float.parseFloat(h1.getText().toString());
                float a=n2/100;
                float r = n1/(a*a);
                if(r>40)
                {
                    String r1=" Overweight "+r;
                    e1.setText(r1.toString());
                }
                else
                {
                    String r2="Normal "+r;
                    e1.setText(r2.toString());
                }
            }
        });






    }
}
